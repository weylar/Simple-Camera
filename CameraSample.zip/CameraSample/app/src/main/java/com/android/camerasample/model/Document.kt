package com.android.camerasample.model

data class Document (
    val document: String,
    val user_id: String
)