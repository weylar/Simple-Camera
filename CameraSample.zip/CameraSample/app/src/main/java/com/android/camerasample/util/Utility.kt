package com.android.camerasample.util



object Utility {

    const val BASE_URL = "https://stage.appruve.co/v1/verifications/test/"
}