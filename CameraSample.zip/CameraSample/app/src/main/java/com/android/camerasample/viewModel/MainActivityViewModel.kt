package com.android.camerasample.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.camerasample.model.Document
import com.android.camerasample.repository.DocumentUploadRepository
import okhttp3.MultipartBody


class MainActivityViewModel(private val repository: DocumentUploadRepository) : ViewModel() {


    fun uploadDocumentImage(image: MultipartBody.Part, userId: String, isSuccess: (result: Boolean) -> Unit ) {
         repository.uploadDocument(image, userId, isSuccess )

    }


}
