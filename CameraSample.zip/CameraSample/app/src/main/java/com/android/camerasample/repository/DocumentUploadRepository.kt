package com.android.camerasample.repository

import android.util.Log
import com.android.camerasample.data.DocumentUploadAPI
import com.android.camerasample.model.Document
import com.android.camerasample.network.Network



import androidx.lifecycle.MutableLiveData
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DocumentUploadRepository{


    fun uploadDocument(documentImage: MultipartBody.Part, userId: String, isSuccess: (result: Boolean) -> Unit) {
        val retrofit = Network.retrofit.create(DocumentUploadAPI::class.java)
        val call: Call<Document> = retrofit.uploadDocument(documentImage, userId)
        call.enqueue(object : Callback<Document> {
            override fun onFailure(call: Call<Document>, t: Throwable) {
                isSuccess(false)
                Log.i("Aminu", t.localizedMessage)

            }

            override fun onResponse(call: Call<Document>, response: Response<Document>) {
                if (response.isSuccessful) {
                  isSuccess(true)
                    Log.i("Aminu", response.message())
                }
            }
        })


    }


}