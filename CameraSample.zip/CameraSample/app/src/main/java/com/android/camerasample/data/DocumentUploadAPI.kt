package com.android.camerasample.data

import com.android.camerasample.model.Document
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*


interface DocumentUploadAPI {

    @POST("/file_upload")
    @Multipart
    fun uploadDocument(
        @Part file: MultipartBody.Part,
        @Part("user_id") userId: String?
    ): Call<Document>
}